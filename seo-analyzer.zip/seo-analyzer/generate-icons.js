// Run with: node generate-icons.js
// Requires Node >= 18. Uses built-in Canvas API via html-canvas or falls back to SVG embed trick.
// This script writes PNG files using pure Node Buffer + raw PNG encoding (no deps).

const fs = require('fs');
const path = require('path');

// Minimal PNG encoder (pure Node, no deps)
function createPNG(size, drawFn) {
  // We'll write an SVG then convert inline — but since we have no canvas in Node easily,
  // we write a self-contained SVG as the icon source instead.
  // Chrome accepts SVG files renamed as .png only in some contexts; use a proper embedded PNG.
  // Strategy: encode a raw 1-bit PNG with our design using zlib (built-in).
  const zlib = require('zlib');

  const w = size, h = size;
  const pixels = new Uint8Array(w * h * 4); // RGBA

  drawFn(pixels, w, h);

  // Build PNG
  function crc32(buf) {
    let crc = 0xffffffff;
    const table = crc32.table || (crc32.table = (() => {
      const t = new Uint32Array(256);
      for (let i = 0; i < 256; i++) {
        let c = i;
        for (let j = 0; j < 8; j++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
        t[i] = c;
      }
      return t;
    })());
    for (let i = 0; i < buf.length; i++) crc = table[(crc ^ buf[i]) & 0xff] ^ (crc >>> 8);
    return (crc ^ 0xffffffff) >>> 0;
  }

  function chunk(type, data) {
    const typeBytes = Buffer.from(type, 'ascii');
    const lenBuf = Buffer.alloc(4);
    lenBuf.writeUInt32BE(data.length);
    const crcData = Buffer.concat([typeBytes, data]);
    const crcBuf = Buffer.alloc(4);
    crcBuf.writeUInt32BE(crc32(crcData));
    return Buffer.concat([lenBuf, typeBytes, data, crcBuf]);
  }

  // IHDR
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(w, 0);
  ihdr.writeUInt32BE(h, 4);
  ihdr[8] = 8; // bit depth
  ihdr[9] = 2; // color type RGB (we'll drop alpha for simplicity → use 6 for RGBA)
  ihdr[9] = 6; // RGBA
  ihdr[10] = 0; ihdr[11] = 0; ihdr[12] = 0;

  // Raw image data with filter bytes
  const raw = Buffer.alloc(h * (1 + w * 4));
  for (let y = 0; y < h; y++) {
    raw[y * (w * 4 + 1)] = 0; // filter None
    for (let x = 0; x < w; x++) {
      const pi = (y * w + x) * 4;
      const ri = y * (w * 4 + 1) + 1 + x * 4;
      raw[ri]   = pixels[pi];
      raw[ri+1] = pixels[pi+1];
      raw[ri+2] = pixels[pi+2];
      raw[ri+3] = pixels[pi+3];
    }
  }

  const compressed = zlib.deflateSync(raw);

  const sig = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);
  return Buffer.concat([sig, chunk('IHDR', ihdr), chunk('IDAT', compressed), chunk('IEND', Buffer.alloc(0))]);
}

function setPixel(pixels, w, x, y, r, g, b, a) {
  if (x < 0 || y < 0 || x >= w || y >= w) return;
  const i = (y * w + x) * 4;
  pixels[i] = r; pixels[i+1] = g; pixels[i+2] = b; pixels[i+3] = a;
}

function fillRect(pixels, w, x0, y0, x1, y1, r, g, b, a) {
  for (let y = y0; y <= y1; y++)
    for (let x = x0; x <= x1; x++)
      setPixel(pixels, w, x, y, r, g, b, a);
}

function fillCircle(pixels, w, cx, cy, radius, r, g, b, a) {
  for (let y = Math.floor(cy - radius); y <= Math.ceil(cy + radius); y++) {
    for (let x = Math.floor(cx - radius); x <= Math.ceil(cx + radius); x++) {
      const dx = x - cx, dy = y - cy;
      if (dx*dx + dy*dy <= radius*radius) setPixel(pixels, w, x, y, r, g, b, a);
    }
  }
}

function drawIcon(pixels, size) {
  const s = size;
  // Background: dark #1a1d27
  fillRect(pixels, s, 0, 0, s-1, s-1, 26, 29, 39, 255);

  // Rounded corners mask (approximate)
  const r = Math.round(s * 0.22);
  // Clear corners
  for (let y = 0; y < r; y++) {
    for (let x = 0; x < r; x++) {
      const dx = r - x - 1, dy = r - y - 1;
      if (dx*dx + dy*dy > r*r) setPixel(pixels, s, x, y, 0, 0, 0, 0);
    }
  }
  for (let y = 0; y < r; y++) {
    for (let x = s-r; x < s; x++) {
      const dx = x - (s-r), dy = r - y - 1;
      if (dx*dx + dy*dy > r*r) setPixel(pixels, s, x, y, 0, 0, 0, 0);
    }
  }
  for (let y = s-r; y < s; y++) {
    for (let x = 0; x < r; x++) {
      const dx = r - x - 1, dy = y - (s-r);
      if (dx*dx + dy*dy > r*r) setPixel(pixels, s, x, y, 0, 0, 0, 0);
    }
  }
  for (let y = s-r; y < s; y++) {
    for (let x = s-r; x < s; x++) {
      const dx = x - (s-r), dy = y - (s-r);
      if (dx*dx + dy*dy > r*r) setPixel(pixels, s, x, y, 0, 0, 0, 0);
    }
  }

  // Draw "SEO" magnifier icon
  const cx = Math.round(s * 0.42), cy = Math.round(s * 0.42);
  const outerR = Math.round(s * 0.28);
  const innerR = Math.round(s * 0.20);
  const thick  = Math.round(s * 0.08);

  // Outer circle (green ring) #22c55e
  fillCircle(pixels, s, cx, cy, outerR, 34, 197, 94, 255);
  // Inner circle (clear)
  fillCircle(pixels, s, cx, cy, innerR, 26, 29, 39, 255);

  // Magnifier handle
  const hx1 = cx + Math.round(outerR * 0.65);
  const hy1 = cy + Math.round(outerR * 0.65);
  const hx2 = cx + Math.round(outerR * 1.25);
  const hy2 = cy + Math.round(outerR * 1.25);
  for (let t = 0; t <= 20; t++) {
    const px = Math.round(hx1 + (hx2-hx1)*t/20);
    const py = Math.round(hy1 + (hy2-hy1)*t/20);
    fillCircle(pixels, s, px, py, thick/2, 34, 197, 94, 255);
  }

  // Small white bars inside circle (simulate text lines)
  const lw = Math.round(innerR * 1.1);
  const lh = Math.round(s * 0.055);
  const lx = cx - Math.round(lw/2);
  for (let i = 0; i < 3; i++) {
    const ly = cy - Math.round(lh) + i * (lh + Math.round(s*0.03));
    const lineW = i === 0 ? lw : Math.round(lw * 0.7);
    fillRect(pixels, s, lx, ly, lx + lineW - 1, ly + lh - 1, 226, 232, 240, 220);
  }
}

const sizes = [16, 32, 48, 128];
const iconsDir = path.join(__dirname, 'icons');
if (!fs.existsSync(iconsDir)) fs.mkdirSync(iconsDir);

sizes.forEach(size => {
  const png = createPNG(size, (pixels, w) => drawIcon(pixels, w));
  fs.writeFileSync(path.join(iconsDir, `icon${size}.png`), png);
  console.log(`icon${size}.png written`);
});

console.log('Done!');
