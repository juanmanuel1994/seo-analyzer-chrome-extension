(() => {
  function analyzeSEO() {
    const result = {
      url: location.href,
      title: null,
      metaDescription: null,
      canonical: null,
      headings: { h1: [], h2: [], h3: [] },
      imagesWithoutAlt: [],
      links: { internal: [], external: [] },
      timestamp: Date.now()
    };

    // Title
    const titleEl = document.querySelector('title');
    result.title = {
      content: titleEl ? titleEl.textContent.trim() : '',
      exists: !!titleEl && titleEl.textContent.trim().length > 0,
      length: titleEl ? titleEl.textContent.trim().length : 0
    };

    // Meta description
    const metaDesc = document.querySelector('meta[name="description"]');
    const metaDescContent = metaDesc ? metaDesc.getAttribute('content') || '' : '';
    result.metaDescription = {
      content: metaDescContent.trim(),
      exists: !!metaDesc && metaDescContent.trim().length > 0,
      length: metaDescContent.trim().length
    };

    // Canonical
    const canonicalEl = document.querySelector('link[rel="canonical"]');
    result.canonical = {
      exists: !!canonicalEl,
      href: canonicalEl ? canonicalEl.getAttribute('href') || '' : ''
    };

    // Headings
    ['h1', 'h2', 'h3'].forEach(tag => {
      document.querySelectorAll(tag).forEach(el => {
        result.headings[tag].push(el.textContent.trim().substring(0, 120));
      });
    });

    // Images without alt
    document.querySelectorAll('img').forEach(img => {
      const alt = img.getAttribute('alt');
      if (alt === null || alt.trim() === '') {
        const src = img.getAttribute('src') || '';
        result.imagesWithoutAlt.push(src.substring(0, 100));
      }
    });

    // Links — collect hrefs for broken-link detection in popup
    const origin = location.origin;
    document.querySelectorAll('a[href]').forEach(a => {
      const href = a.getAttribute('href');
      if (!href || href.startsWith('#') || href.startsWith('javascript:') || href.startsWith('mailto:') || href.startsWith('tel:')) return;

      try {
        const absolute = new URL(href, location.href).href;
        if (absolute.startsWith(origin)) {
          if (result.links.internal.length < 30) result.links.internal.push(absolute);
        } else {
          if (result.links.external.length < 30) result.links.external.push(absolute);
        }
      } catch (_) { /* skip malformed */ }
    });

    return result;
  }

  // Expose via message listener
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg.type === 'SEO_ANALYZE') {
      sendResponse({ data: analyzeSEO() });
    }
    return true;
  });
})();
