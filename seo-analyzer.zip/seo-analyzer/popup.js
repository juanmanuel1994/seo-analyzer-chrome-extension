// ── Helpers ──────────────────────────────────────────────────────────────────

function el(id) { return document.getElementById(id); }

function show(id) { el(id).classList.remove('hidden'); }
function hide(id) { el(id).classList.add('hidden'); }

function clamp(v, min, max) { return Math.max(min, Math.min(max, v)); }

const SVG = {
  check: `<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>`,
  warn:  `<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>`,
  x:     `<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>`,
  chevron: `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>`
};

// ── Score engine ──────────────────────────────────────────────────────────────

function scoreData(d) {
  let score = 100;
  const issues = [];

  // Title (25 pts)
  if (!d.title.exists) {
    score -= 25; issues.push({ sev: 'bad', cat: 'title', msg: 'No <title> tag found' });
  } else if (d.title.length < 30) {
    score -= 12; issues.push({ sev: 'warn', cat: 'title', msg: `Title too short (${d.title.length} chars, min 30)` });
  } else if (d.title.length > 60) {
    score -= 8;  issues.push({ sev: 'warn', cat: 'title', msg: `Title too long (${d.title.length} chars, max 60)` });
  }

  // Meta description (20 pts)
  if (!d.metaDescription.exists) {
    score -= 20; issues.push({ sev: 'bad', cat: 'meta', msg: 'No meta description found' });
  } else if (d.metaDescription.length < 70) {
    score -= 10; issues.push({ sev: 'warn', cat: 'meta', msg: `Meta description too short (${d.metaDescription.length} chars, min 70)` });
  } else if (d.metaDescription.length > 160) {
    score -= 8;  issues.push({ sev: 'warn', cat: 'meta', msg: `Meta description too long (${d.metaDescription.length} chars, max 160)` });
  }

  // H1 (20 pts)
  if (d.headings.h1.length === 0) {
    score -= 20; issues.push({ sev: 'bad', cat: 'headings', msg: 'No H1 tag found' });
  } else if (d.headings.h1.length > 1) {
    score -= 10; issues.push({ sev: 'warn', cat: 'headings', msg: `Multiple H1 tags found (${d.headings.h1.length})` });
  }

  // Canonical (10 pts)
  if (!d.canonical.exists) {
    score -= 10; issues.push({ sev: 'warn', cat: 'canonical', msg: 'No canonical tag found' });
  }

  // Images without alt (15 pts)
  if (d.imagesWithoutAlt.length > 0) {
    const penalty = clamp(d.imagesWithoutAlt.length * 3, 0, 15);
    score -= penalty;
    issues.push({ sev: d.imagesWithoutAlt.length > 3 ? 'bad' : 'warn', cat: 'images', msg: `${d.imagesWithoutAlt.length} image(s) missing alt attribute` });
  }

  // H2 structure (5 pts)
  if (d.headings.h2.length === 0) {
    score -= 5; issues.push({ sev: 'warn', cat: 'headings', msg: 'No H2 tags found' });
  }

  // Links (5 pts — basic check)
  const totalLinks = d.links.internal.length + d.links.external.length;
  if (totalLinks === 0) {
    score -= 5; issues.push({ sev: 'warn', cat: 'links', msg: 'No outbound links detected on this page' });
  }

  score = clamp(Math.round(score), 0, 100);
  return { score, issues };
}

// ── Render ────────────────────────────────────────────────────────────────────

function scoreColor(s) {
  if (s >= 80) return 'var(--green)';
  if (s >= 50) return 'var(--yellow)';
  return 'var(--red)';
}

function scoreLabel(s) {
  if (s >= 80) return 'Good';
  if (s >= 50) return 'Needs Work';
  return 'Poor';
}

function setRing(score) {
  const circ = 2 * Math.PI * 50; // r=50 → 314.16
  const offset = circ - (score / 100) * circ;
  const fill = el('ring-fill');
  fill.style.strokeDashoffset = offset;
  fill.style.stroke = scoreColor(score);
  el('score-value').textContent = score;
  el('score-value').style.color = scoreColor(score);
}

function severityClass(sev) {
  return sev === 'bad' ? 'bad' : sev === 'warn' ? 'warn' : 'good';
}

function buildCategory(title, icon, items) {
  const anyBad  = items.some(i => i.sev === 'bad');
  const anyWarn = items.some(i => i.sev === 'warn');
  const iconClass = anyBad ? 'icon-bad' : anyWarn ? 'icon-warn' : 'icon-good';
  const iconSvg   = anyBad ? SVG.x : anyWarn ? SVG.warn : SVG.check;
  const issueCount = items.filter(i => i.sev !== 'good').length;

  const cat = document.createElement('div');
  cat.className = 'category';

  cat.innerHTML = `
    <div class="cat-header">
      <div class="cat-icon ${iconClass}">${iconSvg}</div>
      <span class="cat-name">${title}</span>
      <span class="cat-count">${issueCount > 0 ? issueCount + ' issue' + (issueCount > 1 ? 's' : '') : 'OK'}</span>
      <span class="cat-chevron">${SVG.chevron}</span>
    </div>
    <div class="cat-body"></div>
  `;

  const header = cat.querySelector('.cat-header');
  const body   = cat.querySelector('.cat-body');
  const chev   = cat.querySelector('.cat-chevron');

  items.forEach(item => {
    const row = document.createElement('div');
    row.className = 'item';
    const dot = `<div class="item-dot dot-${severityClass(item.sev)}"></div>`;
    const tag = item.tag ? `<span class="tag tag-${severityClass(item.sev)}">${item.tag}</span>` : '';
    const val = item.value ? `<div class="item-value ${severityClass(item.sev)}">${item.value}</div>` : '';
    const sub = item.subList ? buildSubList(item.subList, item.maxShow) : '';

    row.innerHTML = `
      ${dot}
      <div class="item-body">
        <div class="item-label">${item.label}${tag}</div>
        ${val}
        ${sub}
      </div>
    `;
    body.appendChild(row);
  });

  header.addEventListener('click', () => {
    body.classList.toggle('open');
    chev.classList.toggle('open');
  });

  // Auto-open if there are issues
  if (issueCount > 0) {
    body.classList.add('open');
    chev.classList.add('open');
  }

  return cat;
}

function buildSubList(items, maxShow = 5) {
  if (!items || items.length === 0) return '';
  const shown = items.slice(0, maxShow);
  const rest  = items.length - shown.length;
  const lis = shown.map(s => `<li>${escHtml(s)}</li>`).join('');
  const more = rest > 0 ? `<p class="more-hint">…and ${rest} more</p>` : '';
  return `<ul class="sub-list">${lis}</ul>${more}`;
}

function escHtml(str) {
  return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function renderResults(data) {
  const { score, issues } = scoreData(data);

  // URL
  el('page-url').textContent = data.url;

  // Ring
  setRing(score);

  // Score title
  el('score-title').textContent = data.title.content || '(no title)';

  // Badges
  const badgesEl = el('score-badges');
  badgesEl.innerHTML = '';
  const scoreStatus = score >= 80 ? 'good' : score >= 50 ? 'warn' : 'bad';
  const badge = document.createElement('span');
  badge.className = `badge badge-${scoreStatus}`;
  badge.innerHTML = (scoreStatus === 'good' ? SVG.check : scoreStatus === 'warn' ? SVG.warn : SVG.x) + ` ${scoreLabel(score)}`;
  badgesEl.appendChild(badge);

  const issuesBadge = document.createElement('span');
  const badCount = issues.filter(i => i.sev === 'bad').length;
  const warnCount = issues.filter(i => i.sev === 'warn').length;
  if (badCount) {
    issuesBadge.className = 'badge badge-bad';
    issuesBadge.innerHTML = `${SVG.x} ${badCount} error${badCount > 1 ? 's' : ''}`;
    badgesEl.appendChild(issuesBadge);
  }
  if (warnCount) {
    const wb = document.createElement('span');
    wb.className = 'badge badge-warn';
    wb.innerHTML = `${SVG.warn} ${warnCount} warning${warnCount > 1 ? 's' : ''}`;
    badgesEl.appendChild(wb);
  }

  // Build categories
  const cats = el('categories');
  cats.innerHTML = '';

  // — Title
  const titleIssue = issues.find(i => i.cat === 'title');
  cats.appendChild(buildCategory('Title Tag', 'title', [
    {
      sev: titleIssue ? titleIssue.sev : 'good',
      label: titleIssue ? titleIssue.msg : `Title looks good (${data.title.length} chars)`,
      tag: data.title.length ? `${data.title.length} chars` : null,
      value: data.title.content ? escHtml(data.title.content.substring(0, 80)) : null
    }
  ]));

  // — Meta Description
  const metaIssue = issues.find(i => i.cat === 'meta');
  cats.appendChild(buildCategory('Meta Description', 'meta', [
    {
      sev: metaIssue ? metaIssue.sev : 'good',
      label: metaIssue ? metaIssue.msg : `Meta description looks good (${data.metaDescription.length} chars)`,
      tag: data.metaDescription.length ? `${data.metaDescription.length} chars` : null,
      value: data.metaDescription.content ? escHtml(data.metaDescription.content.substring(0, 120)) : null
    }
  ]));

  // — Headings
  const headingItems = [];
  const h1Issue  = issues.find(i => i.cat === 'headings' && i.msg.includes('H1'));
  const h2Issue  = issues.find(i => i.cat === 'headings' && i.msg.includes('H2'));

  headingItems.push({
    sev: h1Issue ? h1Issue.sev : 'good',
    label: h1Issue ? h1Issue.msg : `H1 tag present`,
    tag: `${data.headings.h1.length} H1`,
    subList: data.headings.h1
  });
  headingItems.push({
    sev: h2Issue ? h2Issue.sev : 'good',
    label: h2Issue ? h2Issue.msg : `H2 tags found (${data.headings.h2.length})`,
    tag: `${data.headings.h2.length} H2`,
    subList: data.headings.h2
  });
  if (data.headings.h3.length > 0) {
    headingItems.push({
      sev: 'good',
      label: `H3 tags found (${data.headings.h3.length})`,
      tag: `${data.headings.h3.length} H3`,
      subList: data.headings.h3
    });
  }
  cats.appendChild(buildCategory('Headings', 'headings', headingItems));

  // — Canonical
  const canIssue = issues.find(i => i.cat === 'canonical');
  cats.appendChild(buildCategory('Canonical Tag', 'canonical', [
    {
      sev: canIssue ? canIssue.sev : 'good',
      label: canIssue ? canIssue.msg : 'Canonical tag found',
      value: data.canonical.href ? escHtml(data.canonical.href.substring(0, 100)) : null
    }
  ]));

  // — Images
  const imgIssue = issues.find(i => i.cat === 'images');
  cats.appendChild(buildCategory('Images', 'images', [
    {
      sev: imgIssue ? imgIssue.sev : 'good',
      label: imgIssue ? imgIssue.msg : 'All images have alt attributes',
      subList: data.imagesWithoutAlt,
      maxShow: 6
    }
  ]));

  // — Links
  const linkIssue = issues.find(i => i.cat === 'links');
  const linkItems = [];
  linkItems.push({
    sev: linkIssue ? linkIssue.sev : 'good',
    label: linkIssue ? linkIssue.msg : `Links found`,
    tag: `${data.links.internal.length} internal`,
    subList: data.links.internal,
    maxShow: 5
  });
  if (data.links.external.length > 0) {
    linkItems.push({
      sev: 'good',
      label: `External links`,
      tag: `${data.links.external.length} external`,
      subList: data.links.external,
      maxShow: 5
    });
  }
  cats.appendChild(buildCategory('Links', 'links', linkItems));

  hide('state-loading');
  show('state-results');
}

// ── Bootstrap ─────────────────────────────────────────────────────────────────

async function run() {
  show('state-loading');
  hide('state-results');
  hide('state-error');

  let tabs;
  try {
    tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  } catch (e) {
    showError('Could not access tabs.');
    return;
  }

  const tab = tabs[0];
  if (!tab || !tab.id) { showError('No active tab found.'); return; }

  const url = tab.url || '';
  if (url.startsWith('chrome://') || url.startsWith('chrome-extension://') || url.startsWith('about:') || url === '') {
    showError('Cannot analyze browser internal pages.');
    return;
  }

  // Inject content script if needed, then message it
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ['content.js']
    });
  } catch (_) { /* already injected */ }

  chrome.tabs.sendMessage(tab.id, { type: 'SEO_ANALYZE' }, (response) => {
    if (chrome.runtime.lastError || !response || !response.data) {
      showError('Could not analyze this page. Try refreshing it first.');
      return;
    }
    renderResults(response.data);
  });
}

function showError(msg) {
  el('error-msg').textContent = msg;
  hide('state-loading');
  hide('state-results');
  show('state-error');
}

document.addEventListener('DOMContentLoaded', () => {
  run();
  el('btn-refresh').addEventListener('click', run);
});
